#ifndef WATER_INCLUDE_H
#define WATER_INCLUDE_H
texture NormalTex < string name = "Base.tga"; >;
texture ColorTex < string name = "Base.tga"; >;
texture OverlayTex < string name = "Base.tga"; >;
texture FOWTex < string name = "Base.tga"; >;
texture color0 < string name = "Base.tga"; >;	// province color 0 
texture color1 < string name = "Base.tga"; >;	// province color 1
texture stripes < string name = "Base.tga"; >;	// color0 color1 mix


sampler WorldColor  =
sampler_state
{
    Texture = <ColorTex>;
    MinFilter = Linear;
    MagFilter = Linear;
    MipFilter = None;
    AddressU = Wrap;
    AddressV = Wrap;
};

sampler Overlay  =
sampler_state
{
    Texture = <OverlayTex>;
    MinFilter = Linear; //Point;
    MagFilter = Point;
    MipFilter = Linear;
    AddressU = Wrap;
    AddressV = Wrap;
};

///

sampler WaterNormalMap  =
sampler_state
{
    Texture = <NormalTex>;
    MinFilter = Linear; //Point;
    MagFilter = Linear;
    MipFilter = Linear;
    AddressU = Wrap;
    AddressV = Wrap;
//    AddressW = Wrap;
};

sampler FOWTexture  =
sampler_state
{
    Texture = <FOWTex>;
    MinFilter = Linear;
    MagFilter = Linear;
    MipFilter = None;
    AddressU = Wrap;
    AddressV = Wrap;
};

sampler ColorTexture0  =
sampler_state
{
    Texture = <color0>;
    MinFilter = Linear;
    MagFilter = Linear;
    MipFilter = None;
    AddressU = Wrap;
    AddressV = Wrap;
};
sampler ColorTexture1  =
sampler_state
{
    Texture = <color1>;
    MinFilter = Linear;
    MagFilter = Linear;
    MipFilter = None;
    AddressU = Wrap;
    AddressV = Wrap;
};
sampler StripesTexture  =
sampler_state
{
	Texture = <stripes>;
	MinFilter = Linear;
	MagFilter = Linear;
	MipFilter = None;
	AddressU = Wrap;
	AddressV = Wrap;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////


float Fresnel(float NdotL, float fresnelBias, float fresnelPow)

{
  float facing = (1.0 - NdotL);
  return max(fresnelBias +
             (1.0 - fresnelBias) * pow(facing, fresnelPow), 0.0);
}

const float WRAP = 0.8;
const float WaveModOne = 3.0;
const float WaveModTwo =  4.0;

const float SpecValueOne = 20.0;
const float SpecValueTwo =  5.0;

const float vWaterTransparens = 1.0; //more transparance lets you see more of background
const float vColorMapFactor = 2.5f; //how much colormap

#endif

#ifdef SIMPLE

#ifdef PROVINCE_COLOR
float4 PixelShader_WaterSimpleColor( VS_OUTPUT_WATER IN ) : COLOR
#else
float4 PixelShader_WaterSimple( VS_OUTPUT_WATER IN ) : COLOR
#endif
{
	float4 OutColor = float4( 0.3, 0.4, 0.5, 1 );
	

#ifdef PROVINCE_COLOR
	float4 ProvinceColor  = tex2D( ColorTexture0, IN.WorldTexture );
	OutColor = lerp( OutColor, ProvinceColor, 0.8f );
#endif

	float FOW  = saturate( tex2D( FOWTexture, IN.WorldTexture  ).b + 0.6 );
	OutColor.rgb *= FOW;
	return OutColor;
}

#else // SIMPLE

#ifdef FAR
#ifdef PROVINCE_COLOR
float4 PixelShader_WaterFarColor( VS_OUTPUT_WATER IN ) : COLOR
#else // PROVINCE_COLOR
float4 PixelShader_WaterFar( VS_OUTPUT_WATER IN ) : COLOR
#endif // PROVINCE_COLOR
#else // FAR
#ifdef PROVINCE_COLOR
float4 PixelShader_WaterColor( VS_OUTPUT_WATER IN ) : COLOR
#else // PROVINCE_COLOR
float4 PixelShader_Water( VS_OUTPUT_WATER IN ) : COLOR
#endif // PROVINCE_COLOR
#endif // FAR
{
	float3 WorldColorColor = tex2D( WorldColor, IN.vUV ).rgb;

#ifndef FAR
	float2 UV = IN.WorldTexture * 128; ////// size of sea normal.dds 32
	float2 coordA = UV * 0;
	coordA.xy += 0.1;
	float2 coordB = UV;
	coordB.y += 0.1;
	float2 coordC = UV * 0;
	coordC.y += 0.15;
	float2 coordD = UV * 0;
	coordD.y += 0.3;	
		
	float3 vBumpA = tex2D( WaterNormalMap, coordA.xy ).rgb;
	coordB.x -= 0.00 * Time;
	coordB.y += 0.00 * Time;	
	float3 vBumpB = tex2D( WaterNormalMap, coordB.xy ).rgb;
	coordC.x += 0.00 * Time;
	coordC.y -= 0.00 * Time;
	float3 vBumpC = tex2D( WaterNormalMap, coordC.xy ).rgb;
	coordD.x += 0.00 * Time;
	coordD.y -= 0.00 * Time;
	float3 vBumpD = tex2D( WaterNormalMap, coordD.xy + 0.0 * Time ).rgb;

	float3 vBumpTex = normalize(WaveModOne * (vBumpA.xyz + vBumpB.xyz +
                                 vBumpC.xyz + vBumpD.xyz) - WaveModTwo);

	                                         	
	float3 eyeDir = normalize( float3( 0.0, 1.0, 1.0 ) ); 
	float NdotL = max(dot(eyeDir, (vBumpTex)), 0);
	
	//NdotL = saturate((NdotL + WRAP) / (1 + WRAP));
	
	float3 color = NdotL * WorldColorColor; // * vColorMapFactor);
	
	//return float4( color, 1 );
	float3	reflVector = -reflect( float3( 0.0, 0.5, 1.0 ), vBumpTex );
	float	specular = dot( normalize( reflVector), eyeDir );	 
	specular = saturate( specular );
	
	specular = pow( specular, SpecValueOne );
	color += (specular/SpecValueTwo);

#else
	float3 color = WorldColorColor* 0.8;
#endif
	
	float2 WorldTexUV = IN.WorldTexture;
	WorldTexUV += 0.5 / float2( FOW_SIZE_X, FOW_SIZE_Y );
	float xoffset = 0.5 / FOW_SIZE_X;
	float yoffset = 0.5 / FOW_SIZE_Y;

#ifdef PROVINCE_COLOR
	float4 ProvinceColor  = tex2D( ColorTexture0, WorldTexUV + float2( -xoffset, yoffset) );
	ProvinceColor  += tex2D( ColorTexture0, WorldTexUV + float2( xoffset, yoffset) );
	ProvinceColor  += tex2D( ColorTexture0, WorldTexUV + float2( -xoffset, -yoffset) );
	ProvinceColor  += tex2D( ColorTexture0, WorldTexUV + float2( xoffset, -yoffset) );
	ProvinceColor /= 4;

	float4 ProvinceColor1  = tex2D( ColorTexture1, WorldTexUV + float2( -xoffset, yoffset) );
	ProvinceColor1  += tex2D( ColorTexture1, WorldTexUV + float2( xoffset, yoffset) );
	ProvinceColor1  += tex2D( ColorTexture1, WorldTexUV + float2( -xoffset, -yoffset) );
	ProvinceColor1  += tex2D( ColorTexture1, WorldTexUV + float2( xoffset, -yoffset) );
	ProvinceColor1 /= 4;

	float2 TerrainCoord = IN.WorldPos;
	TerrainCoord += 0.5;
	TerrainCoord /= 8.0;
	float vColor = tex2D( StripesTexture, TerrainCoord ).a;
	ProvinceColor = lerp( ProvinceColor, ProvinceColor1, vColor );
	color = lerp( color, ProvinceColor, 0.8f );
#endif
	float4 OutColor = float4( color, vWaterTransparens );

#ifndef FAR
	float2 FOWTI  = tex2D( FOWTexture, WorldTexUV + float2( -xoffset, yoffset) ).ba;
	FOWTI  += tex2D( FOWTexture, WorldTexUV + float2( xoffset, yoffset) ).ba;
	FOWTI  += tex2D( FOWTexture, WorldTexUV + float2( -xoffset, -yoffset) ).ba;
	FOWTI  += tex2D( FOWTexture, WorldTexUV + float2( xoffset, -yoffset) ).ba;
	FOWTI /= 4;
//	OutColor.rgb *= ( 1 - 0.4 * FOWTI.r );
#endif

#ifdef FAR
	float4 overlay = tex2D( Overlay, IN.WorldTexture * float2( 20.0f, 8.0f ) /*IN.WorldPos / 256.0f*/ );
	float3 overlay_mask = overlay < .5;
	
	OutColor.rgb = overlay_mask * (2 * overlay.rgb * OutColor.rgb) + ( 1.0f - overlay_mask )*(1 - 2 * (1 - overlay.rgb) * (1 - OutColor.rgb));
	OutColor.a = OutColor.a * overlay.a;
#endif
	return OutColor;
}

#endif // SIMPLE

#undef SIMPLE
#undef PROVINCE_COLOR
#undef FAR